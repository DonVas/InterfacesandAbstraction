﻿namespace BirthdayCelebrations
{
    using System;
    public interface IBirthable
    {
        DateTime Birthdate { get; }
    }
}