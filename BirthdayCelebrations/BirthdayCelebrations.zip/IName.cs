﻿namespace BirthdayCelebrations
{
    public interface IName
    {
        string Name { get; }
    }
}