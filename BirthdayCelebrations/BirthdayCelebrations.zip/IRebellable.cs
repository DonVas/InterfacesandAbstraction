﻿namespace BirthdayCelebrations
{
    public interface IRebellable
    {
        string Id { get; }
    }
}