﻿using System.Dynamic;

namespace BorderControl
{
    public interface IRebellable
    {
        string Id { get; }
    }
}