﻿namespace Ferrari
{
    public interface IDrivable
    {
        string Gas();

        string Breake();
    }
}