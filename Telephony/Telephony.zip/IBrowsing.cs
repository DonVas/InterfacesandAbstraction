﻿namespace Telephony
{
    public interface IBrowser
    {
        string Browsing( string url);
    }
}