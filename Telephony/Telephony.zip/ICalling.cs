﻿namespace Telephony
{
    public interface ICaller
    {
        string Calling(string number);
    }
}